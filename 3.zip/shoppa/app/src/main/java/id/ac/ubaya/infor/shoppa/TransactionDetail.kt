package id.ac.ubaya.infor.shoppa

data class TransactionDetail(var namaBarang:String, var imgBarang:String, var hrgBarang:Int, var qtyBarang:Int)