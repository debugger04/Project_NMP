package id.ac.ubaya.infor.shoppa

data class Transaction(var no_invoice:String, var tanggal:String, var grandtot:Int, var tipe:String)