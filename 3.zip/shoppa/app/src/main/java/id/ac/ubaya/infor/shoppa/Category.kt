package id.ac.ubaya.infor.shoppa

data class Category(val id:Int, val nama:String, val image:String)