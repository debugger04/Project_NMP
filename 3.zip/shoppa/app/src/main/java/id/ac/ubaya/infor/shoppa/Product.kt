package id.ac.ubaya.infor.shoppa

data class Product(val id:Int, val nama:String, val harga:Int, val deskripsi:String, var likes:Int, val image:String, var qty:Int)